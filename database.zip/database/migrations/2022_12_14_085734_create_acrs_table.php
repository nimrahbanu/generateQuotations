<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('acrs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('project_id')->nullable();   
            $table->unsignedBigInteger('client_name_id')->nullable();
            $table->unsignedBigInteger('contact_no_id')->nullable();
            $table->unsignedBigInteger('district_id')->nullable();
            $table->unsignedBigInteger('state_id')->nullable();
            $table->unsignedBigInteger('whatsapp_no_id')->nullable();
            
            $table->unsignedBigInteger('package_id')->nullable();
            $table->string('request_type');
            $table->string('final_ammount');
            $table->string('bank');
            $table->date('deposit_date')->nullable();
            $table->string('payment_mode');
            $table->string('neft_payment');
            $table->string('amount');
            $table->string('advance_amount');
            $table->string('narration');
            $table->string('attachment');
            $table->date('deleted_date')->nullable();
            $table->timestamps();
            $table->foreign('project_id')->references('id')->on('prospects')->onDelete('SET NULL');
            $table->foreign('client_name_id')->references('id')->on('prospects')->onDelete('SET NULL');
            $table->foreign('contact_no_id')->references('id')->on('prospects')->onDelete('SET NULL');
            $table->foreign('district_id')->references('id')->on('prospects')->onDelete('SET NULL');
            $table->foreign('state_id')->references('id')->on('prospects')->onDelete('SET NULL');
            $table->foreign('whatsapp_no_id')->references('id')->on('prospects')->onDelete('SET NULL');
            $table->foreign('package_id')->references('id')->on('prospects')->onDelete('SET NULL');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('acrs');
    }
};
